## Test environments
 * local OS X install, R 3.2.2
 * win-builder (devel and release)

## R CMD check results
There were no ERRORs, WARNINGs, or NOTEs. 