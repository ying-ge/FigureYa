if(getRversion() >= "2.15.1")  utils::globalVariables(c("signatures.nature2013", "signatures.cosmic", "tri.counts.exome", "tri.counts.genome"))
