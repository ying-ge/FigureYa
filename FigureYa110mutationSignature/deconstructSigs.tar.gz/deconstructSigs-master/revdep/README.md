# Setup

## Platform

|setting  |value                        |
|:--------|:----------------------------|
|version  |R version 3.2.2 (2015-08-14) |
|system   |x86_64, darwin13.4.0         |
|ui       |RStudio (0.98.1103)          |
|language |(EN)                         |
|collate  |en_US.UTF-8                  |
|tz       |Europe/London                |
|date     |2016-07-29                   |

## Packages

|package         |*  |version |date       |source                               |
|:---------------|:--|:-------|:----------|:------------------------------------|
|deconstructSigs |   |1.8.0   |2016-07-29 |local (raerose01/deconstructSigs@NA) |

# Check results
0 packages


